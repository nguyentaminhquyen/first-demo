$('.datepicker').datepicker({
    format: 'yyyy-mm-dd'
});
$("#project_user_ids").select2({
	theme: "bootstrap",
	tags: "true",
	placeholder: "Select member list",
	allowClear: true
});
